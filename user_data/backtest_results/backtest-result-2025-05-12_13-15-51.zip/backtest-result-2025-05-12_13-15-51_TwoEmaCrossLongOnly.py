from freqtrade.strategy import IStrategy, DecimalParameter
from pandas import DataFrame
import talib.abstract as ta
import numpy as np
import pandas as pd
from typing import Optional

class TwoEmaCrossLongOnly(IStrategy):
    timeframe = '1h'
    can_short = True
    use_custom_stoploss = True
    use_custom_exit = True

    # Strategy Parameters
    fast_ema_period = DecimalParameter(5, 50, default=10, space='buy')
    slow_ema_period = DecimalParameter(20, 100, default=20, space='buy')
    atr_period = DecimalParameter(10, 50, default=30, space='buy')
    sl_coef = DecimalParameter(0.5, 3.0, default=1.5, space='buy')
    tp_coef = DecimalParameter(1.0, 5.0, default=3.0, space='buy')
    rsi_period = DecimalParameter(10, 30, default=14, space='buy')
    rsi_threshold = DecimalParameter(50, 70, default=50, space='buy')

    # Minimal ROI and Stoploss (dummy values as we use custom stoploss)
    minimal_roi = {"0": 100}
    stoploss = -0.99

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # EMA Indicators
        dataframe['fast_ema'] = ta.EMA(dataframe['close'], timeperiod=int(self.fast_ema_period.value))
        dataframe['slow_ema'] = ta.EMA(dataframe['close'], timeperiod=int(self.slow_ema_period.value))

        # ATR Indicator
        atr = ta.ATR(dataframe['high'], dataframe['low'], dataframe['close'], timeperiod=int(self.atr_period.value))
        dataframe['atr'] = atr

        # RSI Indicator
        dataframe['rsi'] = ta.RSI(dataframe['close'], timeperiod=int(self.rsi_period.value))

        # EMA Difference for Crossover Detection
        dataframe['ema_diff'] = dataframe['fast_ema'] - dataframe['slow_ema']
        dataframe['ema_diff_prev'] = dataframe['ema_diff'].shift(1)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Long entry on EMA crossover (fast crosses above slow) and RSI above threshold
        dataframe['enter_long'] = (
            (dataframe['ema_diff_prev'] <= 0) & 
            (dataframe['ema_diff'] > 0) &
            (dataframe['rsi'] > self.rsi_threshold.value)
        ).astype('int')

        # Short entry on EMA crossover (fast crosses below slow) and RSI below threshold
        dataframe['enter_short'] = (
            (dataframe['ema_diff_prev'] >= 0) & 
            (dataframe['ema_diff'] < 0) &
            (dataframe['rsi'] < 100 - self.rsi_threshold.value)
        ).astype('int')

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Exit on opposite EMA crossover
        dataframe['exit_long'] = (
            (dataframe['ema_diff_prev'] >= 0) & 
            (dataframe['ema_diff'] < 0)
        ).astype('int')

        dataframe['exit_short'] = (
            (dataframe['ema_diff_prev'] <= 0) & 
            (dataframe['ema_diff'] > 0)
        ).astype('int')

        return dataframe

    def custom_stoploss(self, pair: str, trade, current_time, current_rate, current_profit, **kwargs) -> float:
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe.empty:
            return -0.99

        # Get the latest data for ATR and Slow EMA
        last_row = dataframe.iloc[-1]
        atr_value = last_row['atr']
        slow_ema = last_row['slow_ema']

        if atr_value == 0 or np.isnan(atr_value) or np.isnan(slow_ema):
            return -0.99

        # Calculate initial SL and TP based on ATR
        if trade.is_short:
            sl_price = trade.open_rate + (self.sl_coef.value * atr_value)
            tp_price = trade.open_rate - (self.tp_coef.value * atr_value)
        else:
            sl_price = trade.open_rate - (self.sl_coef.value * atr_value)
            tp_price = trade.open_rate + (self.tp_coef.value * atr_value)

        # Dynamic SL based on Slow EMA
        if trade.is_short:
            if slow_ema < sl_price:
                sl_price = slow_ema
        else:
            if slow_ema > sl_price:
                sl_price = slow_ema

        # Take profit condition
        if (not trade.is_short and current_rate >= tp_price) or (trade.is_short and current_rate <= tp_price):
            return 0  # Close the trade when TP is hit

        # Calculate the stop loss percentage
        sl_percentage = (sl_price / current_rate - 1) if trade.is_short else (sl_price / current_rate) - 1
        return max(sl_percentage, -0.99)

    def custom_stake_amount(self, pair: str, current_time, current_rate: float,
                            proposed_stake: float, min_stake: Optional[float] = None,
                            max_stake: Optional[float] = None, leverage: float = 1.0,
                            entry_tag: Optional[str] = None, side: str = 'long',
                            **kwargs) -> float:
        wallet_balance = self.wallets.get_total(self.config['stake_currency'])
        risk_amount = wallet_balance * (self.sl_coef.value / 100)
        atr_value = self.dp.get_analyzed_dataframe(pair, self.timeframe)['atr'].iloc[-1]
        stop_loss_distance = self.sl_coef.value * atr_value
        position_size = risk_amount / stop_loss_distance
        return max(min(position_size, max_stake if max_stake else float('inf')), min_stake if min_stake else 0)

    plot_config = {
        'main_plot': {
            'fast_ema': {'color': 'blue'},
            'slow_ema': {'color': 'red'}
        },
        'subplots': {
            "RSI": {
                'rsi': {'color': 'purple'}
            },
            "ATR": {
                'atr': {'color': 'green'}
            }
        }
    }
